﻿using CarRentalSystem.Library.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CarRentalSystem
{
    class Program
    {
        static void Main(string[] args)
        {
            // car rental service offers all functions for car rental
            ICarRentalService carRentalService = new CarRentalService();

            // a car can be created with type of CarFactory
            CarFactory sedanFactory = new SedanFactory();
            ICar sedan = sedanFactory.CreateCar();

            // Setup and load inventory with initial stock of cars
            carRentalService.LoadCarsInventory(CarType.Sedan, 10);
            carRentalService.LoadCarsInventory(CarType.SUV, 10);
            carRentalService.LoadCarsInventory(CarType.Van, 10);

            // get total available cars including  Sedan, SUV, Van
            var allAvailableCars = carRentalService.GetAvailableCars();
            Console.WriteLine($"Total available cars: {allAvailableCars.Count}");
            Console.WriteLine();

            // Get available Sedan cars
            var sedans = carRentalService.GetAvailableCars(CarType.Sedan);

            // Get available SUV cars
            var suvs = carRentalService.GetAvailableCars(CarType.SUV);

            // Get available Van type of cars
            var vans = carRentalService.GetAvailableCars(CarType.Van);

            Console.WriteLine($"Total Sedans Available: {sedans.Count}");
            Console.WriteLine($"Total SUVs Available: {suvs.Count}");
            Console.WriteLine($"Total Vans Available: {vans.Count}");

            Console.WriteLine();
            Console.WriteLine($"Sedan cars limit: {sedans.FirstOrDefault().Limit}");
            Console.WriteLine($"SUVs cars limit: {suvs.FirstOrDefault().Limit}");
            Console.WriteLine($"Vans cars limit: {vans.FirstOrDefault().Limit}");        

            DateTime desiredDate = DateTime.Now;
            Console.WriteLine();
            Console.WriteLine("Rent 1 Sedan car");
            // Reserve or Rent 1 Sedan car
            var reservedSedan = carRentalService.ReserveCar(CarType.Sedan, desiredDate, 3, 1);
            if (reservedSedan != null)
                Console.WriteLine($"{reservedSedan.Type} reserved successfully");
            else
                Console.WriteLine($"Cannot reserve {reservedSedan.Type} due to unavailability. Please try other type of cars");

            Console.WriteLine();
            // Check again total available cars after rental
            allAvailableCars = carRentalService.GetAvailableCars();
            Console.WriteLine($"Total available cars:  {allAvailableCars.Count}");
            Console.WriteLine($"Total Sedans Available:  {carRentalService.GetAvailableCars(CarType.Sedan).Count}");

            Console.WriteLine();
            Console.WriteLine("Return 1 Sedan car");
            // Return rented Sedan
            carRentalService.ReturnCar(CarType.Sedan, 1);

            // now check all available cars now
            allAvailableCars = carRentalService.GetAvailableCars();
            
            // check how many Sedans available after rent
            sedans = carRentalService.GetAvailableCars(CarType.Sedan);
            Console.WriteLine($"Total available cars after returning 1 car:  {allAvailableCars.Count}");
            Console.WriteLine($"Total Sedans available after returning 1 Sedan car:  {sedans.Count}");

            Console.WriteLine();
            Console.WriteLine("Rent 6 Sedan cars with exceeding limit");
            // Try renting more than a pre-defined limit
            var rentAttempt = carRentalService.ReserveCar(CarType.Sedan, desiredDate, 3, 6);
            if (rentAttempt != null)
                Console.WriteLine($"{rentAttempt.Type} reserved successfully");
            else
                Console.WriteLine($"Rental failed.");

            Console.ReadLine();
        }
    }
}
