﻿using System;
namespace CarRentalSystem.Library.Repository
{
    /// <summary>
    /// Abstract creator class
    /// </summary>
    public abstract class CarFactory
    {
        public abstract ICar CreateCar();
    }

    /// <summary>
    /// Sedan Factory - Concrete Creater class
    /// </summary>
    public class SedanFactory : CarFactory
    {
        public override ICar CreateCar()
        {
            return new Sedan();
        }
    }

    /// <summary>
    /// SUV Factory - Concrete Creater class
    /// </summary>
    public class SuvFactory: CarFactory
    {
        public override ICar CreateCar()
        {
            return new SUV();
        }
    }
    /// <summary>
    /// Van Factory - Concrete Creater class
    /// </summary>
    public class VanFactory: CarFactory
    {
        public override ICar CreateCar()
        {
            return new Van();
        }
    }    
}