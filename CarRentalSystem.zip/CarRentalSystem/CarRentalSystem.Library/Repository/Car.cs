﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CarRentalSystem.Library.Repository
{
    /// <summary>
    /// Sedan - Concrete Product
    /// </summary>
    public class Sedan : ICar
    {
        public Sedan()
        {
            IsAvailable = true;
        }

        public CarType Type => CarType.Sedan;
        public bool IsAvailable { get; set; }
        public int Limit { get; set; } = 5;

        public void SetLimit(int limit)
        {
            Limit = limit;
        }
    }

    /// <summary>
    /// SUV - Concrete Product
    /// </summary>
    public class SUV : ICar
    {
        public SUV()
        {
            IsAvailable = true;
        }
        public CarType Type => CarType.SUV;
        public bool IsAvailable { get; set; }
        public int Limit { get; set; } = 3;
        public void SetLimit(int limit)
        {
            Limit = limit;
        }
    }

    /// <summary>
    /// Van - Concrete Product
    /// </summary>
    public class Van : ICar
    {
        public Van()
        {
            IsAvailable = true;
        }
        public CarType Type => CarType.Van;
        public bool IsAvailable { get; set; }
        public int Limit { get; set; } = 2;

        /// <summary>
        ///  Set limit
        /// </summary>
        /// <param name="limit"></param>
        public void SetLimit(int limit)
        {
            Limit = limit;
        }
    }    
}
