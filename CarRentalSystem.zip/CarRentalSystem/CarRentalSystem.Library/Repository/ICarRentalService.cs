﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CarRentalSystem.Library.Repository
{
    public interface ICarRentalService
    {
        /// <summary>
        /// Loads Inventory
        /// </summary>
        /// <param name="carType">Car type to load into inventory</param>
        /// <param name="count">provide number of cars</param>
        void LoadCarsInventory(CarType carType, int count);

        /// <summary>
        /// Reserves car for a provided type, date and duration
        /// </summary>
        /// <param name="type">Type of car</param>
        /// <param name="startDate">Date</param>
        /// <param name="durationDays">Duration</param>
        /// <returns>Returns reserved car if reservation is successful, null if no car is available</returns>
        ICar ReserveCar(CarType type, DateTime startDate, int durationDays, int quantity);

        /// <summary>
        /// Get available of total number of cars from the inventory
        /// </summary>
        /// <returns>Total number of available cars from the inventory</returns>
        List<ICar> GetAvailableCars();

        /// <summary>
        /// Gets total number of cars of specific type
        /// </summary>
        /// <param name="carType">Provide car type to get the available count</param>
        /// <returns>Total number of cars of specific type</returns>
        List<ICar> GetAvailableCars(CarType carType);

        /// <summary>
        /// Returns car and inventory is updated with returns
        /// </summary>
        /// <param name="carType">Car type</param>
        /// <param name="count">returning cars count</param>
        void ReturnCar(CarType carType, int count);        
    }
}
