﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CarRentalSystem.Library.Repository
{
    public class Reservation
    {
        public ICar Car { get; }
        public DateTime StartDate { get; }
        public int DurationDays { get; }
        public int Limit { get; }

        public Reservation(ICar car, DateTime startDate, int durationDays)
        {
            Car = car;
            StartDate = startDate;
            DurationDays = durationDays;
        }
    }
}
