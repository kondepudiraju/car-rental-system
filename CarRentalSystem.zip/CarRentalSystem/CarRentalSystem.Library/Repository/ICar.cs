﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CarRentalSystem.Library.Repository
{
    /// <summary>
    /// Abstract Product - Car
    /// </summary>
    public interface ICar
    {
        CarType Type { get; }
        bool IsAvailable { get; set; }
        int Limit { get; set; }
        void SetLimit(int limit);
    }
}