﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CarRentalSystem.Library.Repository
{
    /// <summary>
    /// Car rental service
    /// </summary>
    public class CarRentalService : ICarRentalService
    {
        private readonly List<ICar> _cars;
        private readonly List<Reservation> _reservations;

        public CarRentalService()
        {
            _cars = new List<ICar>();
            _reservations = new List<Reservation>();
        }

        /// <summary>
        /// Loads Inventory
        /// </summary>
        /// <param name="carType">Car type to load into inventory</param>
        /// <param name="count">provide number of cars</param>
        public void LoadCarsInventory(CarType carType, int count)
        {
            if (carType == CarType.Sedan)
            {
                CarFactory sedanFactory = new SedanFactory();
                for (int i = 0; i < count; i++) _cars.Add(sedanFactory.CreateCar());
            }

            if (carType == CarType.SUV)
            {
                CarFactory suvFactory = new SuvFactory();
                for (int i = 0; i < count; i++) _cars.Add(suvFactory.CreateCar());
            }

            if (carType == CarType.Van)
            {
                CarFactory vanFactory = new VanFactory();
                for (int i = 0; i < count; i++) _cars.Add(vanFactory.CreateCar());
            }
        }        

        /// <summary>
        /// Get available of total number of cars from the inventory
        /// </summary>
        /// <returns>Total number of available cars from the inventory</returns>
        public List<ICar> GetAvailableCars()
        {
            return _cars.Where(e => e.IsAvailable).ToList();
        }

        /// <summary>
        /// Gets total number of cars of specific type
        /// </summary>
        /// <param name="carType">Provide car type to get the available count</param>
        /// <returns>Total number of cars of specific type</returns>
        public List<ICar> GetAvailableCars(CarType carType)
        {
            return _cars.Where(e => e.IsAvailable && e.Type == carType).ToList();
        }

        /// <summary>
        /// Reserves car for a provided type, date and duration
        /// </summary>
        /// <param name="type">Type of car</param>
        /// <param name="startDate">Date</param>
        /// <param name="durationDays">Duration</param>
        /// <returns>Returns reserved car if reservation is successful, null if no car is available</returns>
        public ICar ReserveCar(CarType type, DateTime startDate, int durationDays, int quantity)
        {
            // check if any car is available, if not throw null
            ICar reservedCar;
            reservedCar = _cars.FirstOrDefault(car => car.Type == type && car.IsAvailable);

            if (quantity > reservedCar?.Limit)
                return null;
                //throw new Exception($"Limit exceeded. Cannot exceed limit of {reservedCar.Type} cars to {reservedCar.Limit}");

            if (reservedCar != null)
            {
                reservedCar.IsAvailable = false;

                // add to reservation
                var reservation = new Reservation(reservedCar, startDate, durationDays);
                _reservations.Add(reservation);

                // set return date
                var returnDate = startDate.AddDays(durationDays);
                //Console.WriteLine($"Car of type {reservedCar.Type} will be returned on {returnDate.ToShortDateString()}");
                _cars.RemoveAt(_cars.IndexOf(reservedCar));
                return reservedCar;
            }
            return null;
        }

        /// <summary>
        /// Schedules return
        /// </summary>
        /// <param name="car"></param>
        /// <param name="returnDate"></param>
        public void ReturnCar(CarType carType, int count)
        {
            this.LoadCarsInventory(carType, count);
        }
    }
}
