﻿using System;
using CarRentalSystem.Library.Repository;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace CarRentalSystem.TestMethod
{
    [TestClass]
    public class CarFactoryTests
    {
        [TestMethod]
        public void CreateCar_Sedan_ReturnsSedanInstance()
        {
            CarFactory sedanFactory = new SedanFactory();
            ICar car = sedanFactory.CreateCar();

            Assert.IsNotNull(car);
            Assert.AreEqual(CarType.Sedan, car.Type);
            Assert.IsTrue(car.IsAvailable);
        }

        [TestMethod]
        public void CreateCar_SUV_ReturnsSUVInstance()
        {
            CarFactory suvFactory = new SuvFactory();
            ICar car = suvFactory.CreateCar();
            Assert.IsNotNull(car);
            Assert.AreEqual(CarType.SUV, car.Type);
            Assert.IsTrue(car.IsAvailable);
        }

        [TestMethod]
        public void CreateCar_Van_ReturnsVanInstance()
        {
            CarFactory vanFactory = new VanFactory();
            ICar car = vanFactory.CreateCar();
            Assert.IsNotNull(car);
            Assert.AreEqual(CarType.Van, car.Type);
            Assert.IsTrue(car.IsAvailable);
        }       
    }
}
