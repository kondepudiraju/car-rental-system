﻿using System;
using CarRentalSystem.Library.Repository;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace CarRentalSystem.TestMethod
{
    [TestClass]
    public class CarRentalSystemTest
    {
        [TestMethod]
        public void Test_Inventory_Availability()
        {
            // Arrange
            ICarRentalService carRentalService = new CarRentalService();
            carRentalService.LoadCarsInventory(CarType.Sedan, 10);
            carRentalService.LoadCarsInventory(CarType.SUV, 10);
            carRentalService.LoadCarsInventory(CarType.Van, 10);
            DateTime startDate = DateTime.Now;

            // Act
            var totalAvailableCars = carRentalService.GetAvailableCars().Count;
            var sedans = carRentalService.GetAvailableCars(CarType.Sedan).Count;
            var suvs = carRentalService.GetAvailableCars(CarType.SUV).Count;
            var vans = carRentalService.GetAvailableCars(CarType.Van).Count;

            // Assert Available cars
            Assert.AreEqual(30, totalAvailableCars);
            Assert.AreEqual(10, sedans);
            Assert.AreEqual(10, suvs);
            Assert.AreEqual(10, vans);

            var rentSedan = carRentalService.ReserveCar(CarType.Sedan, startDate, 2, 1);
            var rentSuv = carRentalService.ReserveCar(CarType.SUV, startDate, 2, 1);
            var rentVan = carRentalService.ReserveCar(CarType.Van, startDate, 2, 1);

            // Assert
            Assert.IsNotNull(rentSedan);
            Assert.IsNotNull(rentSuv);
            Assert.IsNotNull(rentVan);

            // Check counts after rents and ensure counts matches
            totalAvailableCars = carRentalService.GetAvailableCars().Count;
            sedans = carRentalService.GetAvailableCars(CarType.Sedan).Count;
            suvs = carRentalService.GetAvailableCars(CarType.SUV).Count;
            vans = carRentalService.GetAvailableCars(CarType.Van).Count;

            Assert.AreEqual(27, totalAvailableCars);
            Assert.AreEqual(9, sedans);
            Assert.AreEqual(9, suvs);
            Assert.AreEqual(9, vans);
        }

        [TestMethod]
        public void Test_ReserveCar_Sedan_Success()
        {
            // Arrange
            ICarRentalService carRentalService = new CarRentalService();
            carRentalService.LoadCarsInventory(CarType.Sedan, 10);
            DateTime startDate = DateTime.Now;

            // Act
            var reservedCar = carRentalService.ReserveCar(CarType.Sedan, DateTime.Now, 2, 1);

            // Assert
            Assert.IsNotNull(reservedCar);
            Assert.AreEqual(reservedCar.Type, CarType.Sedan);
        }

        [TestMethod]
        public void Test_ReserveCar_SUV_Success()
        {
            // Arrange
            ICarRentalService carRentalService = new CarRentalService();
            carRentalService.LoadCarsInventory(CarType.SUV, 1);
            DateTime startDate = DateTime.Now;

            // Act
            var reservedCar = carRentalService.ReserveCar(CarType.SUV, new DateTime(2024, 11, 15), 2, 1);

            // Assert
            Assert.IsNotNull(reservedCar);
            Assert.AreEqual(reservedCar.Type, CarType.SUV);
        }

        [TestMethod]
        public void Test_ReserveCar_Van_Success()
        {
            // Arrange
            ICarRentalService carRentalService = new CarRentalService();
            carRentalService.LoadCarsInventory(CarType.Van, 1);
            DateTime startDate = DateTime.Now;

            // Act
            var reservedCar = carRentalService.ReserveCar(CarType.Van, new DateTime(2024, 11, 15), 2, 1);

            // Assert
            Assert.IsNotNull(reservedCar);
            Assert.AreEqual(reservedCar.Type, CarType.Van);
        }

        [TestMethod]
        public void Test_ReturnCar()
        {
            // Arrange
            ICarRentalService carRentalService = new CarRentalService();
            carRentalService.LoadCarsInventory(CarType.Sedan, 10);
            DateTime startDate = DateTime.Now;

            // Act
            var reservedCar = carRentalService.ReserveCar(CarType.Sedan, new DateTime(2024, 11, 15), 2, 1);
            var sedans = carRentalService.GetAvailableCars(CarType.Sedan).Count;

            // Assert
            Assert.IsNotNull(reservedCar);
            Assert.AreEqual(reservedCar.Type, CarType.Sedan);
            Assert.AreEqual(9, sedans);

            carRentalService.ReturnCar(CarType.Sedan, 1);
            sedans = carRentalService.GetAvailableCars(CarType.Sedan).Count;
            Assert.AreEqual(10, sedans);
        }

        [TestMethod]
        public void Test_ExceedLimit()
        {
            // Arrange
            ICarRentalService carRentalService = new CarRentalService();
            carRentalService.LoadCarsInventory(CarType.Sedan, 10);
            DateTime startDate = DateTime.Now;

            // Act
            var reservedCar = carRentalService.ReserveCar(CarType.Sedan, startDate, 2, 1);
            var secondAttempt = carRentalService.ReserveCar(CarType.Sedan, startDate, 2, 6);

            // Assert
            Assert.IsNotNull(reservedCar);
            Assert.AreEqual(reservedCar.Type, CarType.Sedan);
            Assert.AreEqual(5, reservedCar.Limit); // check Sedan's limit with default limit 5
            Assert.IsNull(secondAttempt);
        }

        [TestMethod]
        public void Test_ReserveCar_Failure_NoAvailableCars()
        {
            // Arrange
            ICarRentalService carRentalService = new CarRentalService();
            carRentalService.LoadCarsInventory(CarType.Sedan, 1);
            DateTime startDate = DateTime.Now;

            // Act
            var firstRent = carRentalService.ReserveCar(CarType.Sedan, DateTime.Now, 1, 1);
            var secondRentForSedan = carRentalService.ReserveCar(CarType.Sedan, DateTime.Now, 1, 1);

            // Assert
            Assert.IsNotNull(firstRent);
            Assert.IsNull(secondRentForSedan, "Second car rent should be failed due to unavailability"); // should be null for second rent attempt as there was only 1 car
        }

        [TestMethod]
        public void Test_MultipleReservations()
        {
            // Arrange
            ICarRentalService carRentalService = new CarRentalService();
            carRentalService.LoadCarsInventory(CarType.Sedan, 1);
            carRentalService.LoadCarsInventory(CarType.SUV, 1);

            // Act
            var reservedCar = carRentalService.ReserveCar(CarType.Sedan, DateTime.Now, 2, 1);
            var secondRservedCar = carRentalService.ReserveCar(CarType.SUV, DateTime.Now, 2, 1);

            // Assert
            Assert.IsNotNull(reservedCar, "First car reservation should be successful.");
            Assert.IsNotNull(secondRservedCar, "Second car should also be successful.");
        }
    }
}
